// Vercel Serverless Function — HorsePay Webhook
// POST /api/hp-webhook
// Recebe callback da HorsePay quando pagamento é confirmado
// Salva o status em memória (KV via cookies/headers) e notifica o client via SSE

const crypto = require('crypto');

// HMAC secret da HorsePay
const HMAC_SECRET = '0a0609386226356c257b20c76bf55f18ab61f43138aefa08948bf1f9919df30e';

// Armazena pagamentos confirmados em memória (persiste durante a vida do serverless)
// Para produção robusta, usar Vercel KV ou Redis
const paidOrders = new Map();

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Signature');

  if (req.method === 'OPTIONS') return res.status(200).end();

  // ── GET: client pergunta se pedido foi pago ──────────────────────────────
  if (req.method === 'GET') {
    const { order_id } = req.query;
    if (!order_id) return res.status(400).json({ error: 'order_id required' });
    const paid = paidOrders.has(String(order_id));
    return res.status(200).json({ paid, order_id });
  }

  // ── POST: recebe webhook da HorsePay ────────────────────────────────────
  if (req.method === 'POST') {
    try {
      // Valida assinatura HMAC se presente
      const signature = req.headers['x-signature'];
      if (signature && HMAC_SECRET) {
        const rawBody = JSON.stringify(req.body);
        const expected = 'sha256=' + crypto
          .createHmac('sha256', HMAC_SECRET)
          .update(rawBody)
          .digest('hex');
        try {
          const valid = crypto.timingSafeEqual(
            Buffer.from(signature),
            Buffer.from(expected)
          );
          if (!valid) {
            console.error('HMAC inválido');
            return res.status(401).json({ error: 'Assinatura inválida' });
          }
        } catch(e) {
          return res.status(401).json({ error: 'Assinatura inválida' });
        }
      }

      const { external_id, status, client_reference_id } = req.body || {};

      console.log('HorsePay webhook:', { external_id, status, client_reference_id });

      // Pagamento confirmado
      if (status === true || status === 'paid') {
        if (external_id) {
          paidOrders.set(String(external_id), {
            paid_at: new Date().toISOString(),
            client_reference_id
          });
          console.log(`Pedido ${external_id} marcado como PAGO`);
        }
      }

      return res.status(200).json({ success: true });
    } catch(err) {
      console.error('Webhook error:', err);
      return res.status(500).json({ error: err.message });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
};
